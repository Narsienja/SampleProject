# ACS AEM Samples

#### Samples index: [http://adobe-consulting-services.github.io/acs-aem-samples/#samples](http://adobe-consulting-services.github.io/acs-aem-samples/#samples)

This project is a collection of sample implementation of the various, common building blocks for AEM-based applications.

The samples in this project are not intended and should never be installed on AEM instance directly and only used for
 reference purposes.

 These samples have not been tested for functionality; please report and bugs/incorrectness to the ACS AEM Samples
GitHub Issues project.

